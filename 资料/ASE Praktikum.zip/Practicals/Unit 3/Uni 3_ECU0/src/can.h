void CANInit(void);
void CAN_MessageBufferInit(void);