#include "jdp.h" 

void ADC_StartConversion()
{
    // start ADC0 conversion
    ADC_0.MCR.B.NSTART = 1;
    // wait until conversion is completed
    while(ADC_0.MSR.B.NSTART);
}

void ADCInit()
{
    // disable Power Down Mode
    ADC_0.MCR.B.PWDN = 0;
    // Single Shot Mode
    ADC_0.MCR.B.MODE = 0;
    // Overwrite Enable
    ADC_0.MCR.B.OWREN = 1;
    // Channel 4 aktivieren (Potentiometer)
    ADC_0.NCMR[0].B.CH4 = 1;
    // Channel 2 ANA IN1
    ADC_0.NCMR[0].B.CH2 = 1;
    // Channel 5 Temperature
    ADC_0.NCMR[0].B.CH5 = 1;
}