void ADCInit(void);
void ADC_StartConversion(void);