void PITInit(void);
void PIT_ConfigureTimer(char timerChannel, unsigned int loadValue);
void PIT_StartTimer(char timerChannel);
void PIT_StopTimer(char timerChannel);
