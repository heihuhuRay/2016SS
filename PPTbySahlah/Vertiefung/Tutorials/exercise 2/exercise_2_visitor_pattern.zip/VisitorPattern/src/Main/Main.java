package Main;

import Tree.TreeLeaf;
import Tree.TreeNode;
import Visitor.SummingIntegerVisitor;

/**
 * @author mfrank
 *
 *         The Main class contains the main methode to start the example
 */

public class Main {

	/**
	 * @param args
	 * 
	 *            Starts the program. During that it creates a tree with two
	 *            leafs (L=5 , N , R=3) and a visitor, which goes throu the
	 *            tree.
	 * 
	 */
	public static void main(String[] args) {
		// ceates sample tree
		TreeNode<Integer> sampleTree = new TreeNode<Integer>(new TreeLeaf<Integer>(new Integer(5)),
				new TreeLeaf<Integer>(new Integer(3)));
		SummingIntegerVisitor visitor = new SummingIntegerVisitor();

		// Starts the visiting the tree
		visitor.visitTreeNode(sampleTree);

		// Collect the result and prints it.
		System.out.println("----- result -----");
		System.out.println(visitor.getSum());
	}

}
