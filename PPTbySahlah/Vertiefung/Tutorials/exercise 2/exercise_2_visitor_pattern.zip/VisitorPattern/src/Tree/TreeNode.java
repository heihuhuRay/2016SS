package Tree;

import Visitor.IVisitor;

/**
 * 
 * Implementation of the TreeNode, which implements the accept method from the
 * interface TreeElement.
 * 
 * @author mfrank
 *
 * @param <T>
 *            generic type of the tree
 */

public class TreeNode<T> implements TreeElement<T> {

	// left sub tree
	private TreeElement<T> left;

	// right sub tree
	private TreeElement<T> right;

	/**
	 * Constructor
	 *
	 * @param left
	 *            left sub tree
	 * @param right
	 *            right sub tree
	 */
	public TreeNode(TreeElement<T> left, TreeElement<T> right) {
		super();
		this.left = left;
		this.right = right;
	}

	/**
	 * Implements the accept method from the interface and ensures that the the
	 * right method with this class is called on the given visitor.
	 */
	public void accept(IVisitor<T> visitor) {
		visitor.visitTreeNode(this);
	}

	/**
	 * @return false if there is no left subtree
	 */
	public boolean hasLeft() {
		return left != null;
	}

	/**
	 * @return false if there is no right subtree
	 */
	public boolean hasRight() {
		return right != null;
	}

	/**
	 * Returns null if there is no left subtree;
	 * 
	 * @return the left subtree
	 */
	public TreeElement<T> getLeft() {
		return left;
	}

	/**
	 * Returns null if there is no right subtree;
	 * 
	 * @return the right subtree
	 */
	public TreeElement<T> getRight() {
		return right;
	}

	public void setLeft(TreeElement<T> left) {
		this.left = left;
	}

	public void setRight(TreeElement<T> right) {
		this.right = right;
	}
}
