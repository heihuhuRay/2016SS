package Tree;

import Visitor.IVisitor;

/**
 * 
 * TreeElement interface, that provides the accept method, which needs to be
 * implemented by all elements of the tree.
 * 
 * @author mfrank
 *
 * @param <T>
 */
public interface TreeElement<T> {

	/**
	 * accept method, that should call the corresponding visit method on the
	 * visitor.
	 * 
	 * @param visitor
	 */
	public void accept(IVisitor<T> visitor);

}
