package Tree;

import Visitor.IVisitor;

/**
 * Implementation of the TreeLeaf, which implements the accept method from the
 * interface TreeElement.
 * 
 * @author mfrank
 *
 * @param <T>
 */
public class TreeLeaf<T> implements TreeElement<T> {

	private final T value;

	/**
	 * Constructor
	 * 
	 * @param value
	 *            of the TreeLeaf element
	 */
	public TreeLeaf(final T value) {
		super();
		this.value = value;
	}

	/**
	 * Implements the accept method from the interface and ensures that the the
	 * right method with this class is called on the given visitor.
	 */
	public void accept(IVisitor<T> visitor) {
		visitor.visitLeafElement(this);
	}

	/**
	 * Returns the value of the tree from type T. Can be null, false, or 0, etc.
	 * in case it is not set.
	 * 
	 * @return value of the tree.
	 */
	public T getValue() {
		return value;
	}
}
