package Visitor;

import Tree.TreeLeaf;
import Tree.TreeNode;

/**
 * Implementation of the SummingIntegerVisitor which implements the IVisitor
 * interface and travels throu the tree while summing the values of all
 * LeafElements
 * 
 * @author mfrank
 *
 */
public class SummingIntegerVisitor implements IVisitor<Integer> {

	// total sum
	private int sum;

	/**
	 * Construtor
	 */
	public SummingIntegerVisitor() {
		super();
		sum = 0;
	}

	/**
	 * Implements the method for the TreeNode. Depending on the avalibility of a
	 * left or right subtree the accepet (visit) method on the subtree element
	 * is called.
	 * 
	 * Recrusive method that stops all elements have been visited. No
	 * check/support for circular trees
	 */
	@Override
	public void visitTreeNode(final TreeNode<Integer> tn) {

		// Trace of the visiting
		System.out.println("----- visit -----");
		System.out.println("Node: " + tn);
		System.out.println("hasLeft: " + tn.hasLeft());
		System.out.println("hasRight: " + tn.hasRight());

		// first visit the left sub tree
		if (tn.hasLeft()) {
			tn.getLeft().accept(this);
		}
		// then the right one
		if (tn.hasRight()) {
			tn.getRight().accept(this);
		}
	}

	/*
	 * This method is called when the TreeElement is a leaf. The method is
	 * summing the value of the element to the total.
	 */
	@Override
	public void visitLeafElement(final TreeLeaf<Integer> tl) {
		// Trace of summing
		System.out.println("----- add to sum -----");
		System.out.println(tl.getValue());

		sum += tl.getValue();
	}

	/**
	 * Returns the current sum
	 * 
	 * @return current sum
	 */
	public Integer getSum() {
		return sum;
	}

}
