package Visitor;

import Tree.TreeLeaf;
import Tree.TreeNode;

/**
 * Visitor interface, which should be implemented by all visitors.
 * 
 * @author mfrank
 *
 * @param <T>
 *            generic type for the visitor, depending on the type of tree
 */
public interface IVisitor<T> {

	/**
	 * Method for the TreeNode. It is called from the TreeNode whenever it is
	 * visited
	 * 
	 * @param tn
	 *            calling tree node
	 */
	public void visitTreeNode(TreeNode<T> tn);

	/**
	 * Method for the LeafElement. It is called from the LeafElement whenever it
	 * is visited.
	 * 
	 * @param tl
	 *            calling leaf element
	 */
	public void visitLeafElement(TreeLeaf<T> tl);

}
