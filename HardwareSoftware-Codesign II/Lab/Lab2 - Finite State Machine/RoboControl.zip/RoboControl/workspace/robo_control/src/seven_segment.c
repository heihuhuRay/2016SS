#include <math.h>
#include "xiomodule.h"
#include "robo_control.h"
#include "seven_segment.h"

void updateSevenSegment ( void )
{
	/* ------------------------------
	 * -- Your code here
	 * ------------------------------
	 */

	return;
}
