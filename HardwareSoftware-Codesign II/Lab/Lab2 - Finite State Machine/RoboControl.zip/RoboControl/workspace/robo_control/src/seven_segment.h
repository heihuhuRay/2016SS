#ifndef __SEVEN_SEGMENT_H__
#define __SEVEN_SEGMENT_H__

/*	------------------------------
 *	-- updateSevenSegment
 *	------------------------------
 *
 * 	- reads value from switch
 * 	- updates seven segment display with according engine value:
 * 		- converts float into 4-byte digits
 * 		- sets flag for negative values
 */

void updateSevenSegment ( void );

#endif // __SEVEN_SEGMENT_H__
