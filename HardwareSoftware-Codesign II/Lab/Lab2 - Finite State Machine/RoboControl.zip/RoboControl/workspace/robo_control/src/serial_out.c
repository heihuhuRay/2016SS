#include "xiomodule.h"
#include "robo_control.h"
#include "serial_out.h"

void sendByte ( char byte )
{
	/* ------------------------------
	 * -- Your code here
	 * ------------------------------
	 */
}

void sendData ( void )
{
	/* ------------------------------
	 * -- Your code here
	 * ------------------------------
	 */
}
