#ifndef __STATE_H__
#define __STATE_H__

/*	------------------------------
 *	-- updateState
 *	------------------------------
 *
 * 	- performs received command on given engine number
 * 	- checks for collision
 * 	- reverts to old value when collision is detected
 */

u8 updateState ( u8 engineNr, u8 cmd );

#endif // __STATE_H__
