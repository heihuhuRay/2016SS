#include <math.h>
#include "xiomodule.h"
#include "robo_control.h"
#include "state.h"

u8 updateState ( u8 engineNr, u8 cmd )
{

	u8 collisionState = 0; // could set to  engine or variable id for debug where detected

	/* ------------------------------
	 * -- Your code here
	 * ------------------------------
	 */

	return collisionState;
}
