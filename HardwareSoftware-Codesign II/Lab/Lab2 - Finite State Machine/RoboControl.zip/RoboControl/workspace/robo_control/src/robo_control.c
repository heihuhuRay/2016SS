/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */

#include <stdio.h>
#include <math.h>
#include "platform.h"
#include "xparameters.h"
#include "xiomodule.h"
#include "state.h"
#include "serial_out.h"
#include "seven_segment.h"
#include "robo_control.h"

void isrTxAck ( void )
{
	/* ------------------------------
	 * -- Your code here
	 * ------------------------------
	 */

	return;
}

void isrRxReq ( void )
{
	/* ------------------------------
	 * -- Your code here
	 * ------------------------------
	 */

	return;
}

void ackTimeout ( void )
{
	u8 i = 0;
	for (i=0;i<1;) i++;
}

int main ()
{

    init_platform();

    // Initialize
    XIOModule_Initialize(&ioModule, XPAR_IOMODULE_0_DEVICE_ID);

    // Register Interrupthandler
    microblaze_register_handler(XIOModule_DeviceInterruptHandler, XPAR_IOMODULE_0_DEVICE_ID);

    // Connect/Enable ISR for Seven Segment Display
	XIOModule_Connect(&ioModule, INT_TX_ACK, (XInterruptHandler) isrTxAck, XPAR_IOMODULE_0_DEVICE_ID);
	XIOModule_Enable(&ioModule, INT_TX_ACK);

	// Connect/Enable ISR for Seven Segment Display
	XIOModule_Connect(&ioModule, INT_RX_REQ, (XInterruptHandler) isrRxReq, XPAR_IOMODULE_0_DEVICE_ID);
	XIOModule_Enable(&ioModule, INT_RX_REQ);

    // enable Interrupts
    microblaze_enable_interrupts();

    // main loop
    while (1)
    {
    	// Update Seven Segment Display
    	updateSevenSegment();

    	// Send back Data (if needed)
    	if (sendBack)
    	{
			sendData();
    	}
    }

    cleanup_platform();

    return 0;
}
